package com.himanshuhc.locationupdates;

public class LocationReceivers {

    protected void createLocationRequest() {

    }

}
